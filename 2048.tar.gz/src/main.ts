import { createApp } from 'vue'
import App from './App.vue'
import 'bootstrap/js/dist/base-component'
import 'bootstrap/js/dist/button'
import 'bootstrap/js/dist/dropdown'
import './bootstrap.sass'
createApp(App).mount('#app')
